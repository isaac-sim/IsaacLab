Changelog
---------

0.1.0 (2024-01-29)
~~~~~~~~~~~~~~~~~~

Added
^^^^^

* Created an initial template for building an extension or project based on Orbit
